<?php

include 'koneksi.php';

$id 	= $_GET['id'];

$sql 	= "DELETE FROM data_mhs WHERE nim='$id'";
$query	= mysqli_query($connect, $sql);

if ($query) {
	header("location: index.php");
} else {
	echo "Hapus Data Gagal.";
}
