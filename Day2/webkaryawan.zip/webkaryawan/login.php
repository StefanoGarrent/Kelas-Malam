<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <center><H1>Login</H1></center>

    <?php
        if(isset($_GET['pesan'])){
            if($_GET['pesan'] == "gagal")
            {
                // echo "Login gagal. Email atau password salah.";
                ?>
                <script>alert('Login gagal. Email atau password salah.')</script>
                <?php
            } elseif ($_GET['pesan'] == "logout")
            {
                // echo "Logout berhasil";
                ?>
                <script>alert('Logout Berhasil')</script>
                <?php
            } elseif ($_GET['pesan'] == "belum_login")
            {
                echo "Anda harus login terlebih dahulu";
            }
        }
    ?>

    <div class="container">
    <form method="POST" action="login_proses.php">
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Email address</label>
            <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Password</label>
            <input type="password" name="password" class="form-control" id="exampleInputPassword1">
        </div>
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    </div>
</body>
</html>