<?php
	include 'koneksi.php';

	$nim_lama	= $_POST['nim_lama'];
	$nim_baru	= $_POST['nim_baru'];
	$nama		= $_POST['nama'];
	$angkatan	= $_POST['angkatan'];
	$sks		= $_POST['sks'];

	$sql	= "UPDATE data_mhs SET nim='$nim_baru', nama='$nama', angkatan='$angkatan', sks='$sks' WHERE nim='$nim_lama'";

	$query	= mysqli_query($connect, $sql) or die(mysqli_error($connect));

	if($query) {
		header("location: index.php");
	} else {
		echo "Input Data Gagal.";
	}
?>