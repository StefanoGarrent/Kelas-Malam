<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
</head>
<body>
	<center>
		<h1>LOGIN</h1>
		<?php
			if(isset($_GET['message'])) {
				if($_GET['message'] == "failed") {
					echo "Login gagal. Username atau password salah.";
				} elseif ($_GET['message'] == "logout") {
					echo "Anda telah berhasil logout.";
				} elseif ($_GET['message'] == "belum_login") {
					echo "Anda harus login terlebih dahulu untuk mengakses halaman admin.";
				}
			}
		?>
		<br><br>
		<form method="POST" action="login_proses.php">
			<input type="text" name="username" placeholder="Username">
			<br><br>
			<input type="password" name="password" placeholder="Password">
			<br><br><br>
			<input type="submit" name="" value="LOGIN">
		</form>
	</center>
</body>
</html>