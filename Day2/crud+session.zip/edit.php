<?php

session_start();

if(empty($_SESSION['username'])) {
	header("location: login.php?message=belum_login");
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>UPDATE</title>
</head>
<body>
	<center>
		<h1>Ubah Data Mahasiswa</h1>
		<a href="index.php">Lihat Data</a>
		<br>
		<br>
		<form method="POST" action="edit_proses.php">
			<?php
			include('koneksi.php');

			$nim = $_GET['id'];

			$sql	= "SELECT * FROM data_mhs WHERE nim='$nim'";
			$query	= mysqli_query($connect, $sql);

			while ($data = mysqli_fetch_array($query)) {
			?>
			<table>
				<input type="hidden" name="nim_lama" value="<?= $data['nim']; ?>">
				<tr>
					<td>NIM</td>
					<td><input type="text" name="nim_baru" value="<?= $data['nim']; ?>"></td>
				</tr>
				<tr>
					<td>Nama</td>
					<td><input type="text" name="nama" value="<?= $data['nama']; ?>"></td>
				</tr>
				<tr>
					<td>Angkatan</td>
					<td><input type="text" name="angkatan" value="<?= $data['angkatan']; ?>"></td>
				</tr>
				<tr>
					<td>SKS</td>
					<td><input type="text" name="sks" value="<?= $data['sks']; ?>"></td>
				</tr>
			</table>
			<?php } ?>
			<br>
			<input type="submit" name="">
		</form>
	</center>
</body>
</html>